# frozen_string_literal: true

module OrdersHelper
end
