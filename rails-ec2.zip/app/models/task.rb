# frozen_string_literal: true

class Task < ApplicationRecord
end
