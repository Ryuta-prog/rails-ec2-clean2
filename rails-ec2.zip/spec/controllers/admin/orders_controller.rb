# frozen_string_literal: true

redirect_to admin_orders_path, alert: t('admin.orders.not_found')
