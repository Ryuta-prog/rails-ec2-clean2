# frozen_string_literal: true

require 'rails_helper'

RSpec.describe 'Admin::Products' do
  describe 'GET /index' do
    pending "add some examples (or delete) #{__FILE__}"
  end
end
